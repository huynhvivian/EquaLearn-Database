from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
import django.contrib.staticfiles
import random
import calendar
from datetime import date
from datetime import datetime
from datetime import timedelta
from .models import User
from .models import Tutor
from .models import Client
from .models import Student
from .models import Session
from .models import Subject
from .models import Takes
from .models import Location
from.models import schedule_student
from .models import preferred_student



# Create your views here.
def volunteer_dashboard(request, id):
    #id = volunteer's user ID
    tutor = Tutor.objects.get(User_ID = id)
    sessions = Session.objects.filter(user_id_tutor = id)
    return render(request, 'volunteerdashboard.html', {'sessions': sessions, 'tutor': tutor})

def volunteer_hours(request, id):
    tutor = Tutor.objects.get(User_ID = id)
    sessions = Session.objects.filter(status ='Verified', user_id_tutor = id)
    total = 0
    for session in sessions:
        total = total + session.totalhours()

    return render(request, 'viewhours.html', {'sessions': sessions, 'hours': total, 'tutor': tutor})

def session_signups(request, id):
    tutor = Tutor.objects.get(User_ID = id)
    takes = Takes.objects.filter(current_tutor = None)
    student_schedules = schedule_student.objects.all()
    student_locations = preferred_student.objects.all()
    return render(request, 'sessionsignups.html', {'takes': takes, 'tutor': tutor, 'schedules':student_schedules, 'student_locations': student_locations})

def sessions_signed_up(request, tid, student, takeid):
    #Make sessions from next-next session to the end... so we'd need current date, the weekday, ummm
    currentday = datetime.date(datetime.now())
    thistake = Takes.objects.get(takes_id = takeid)
    thistake.current_tutor = Tutor.objects.get(User_ID = tid)
    thistake.save()
    endday = thistake.end_date


    loc = request.POST.get('chooseloc')
    time = request.POST.get('choosetime')
    if (loc == '' or time == ''):
        #no time or location filled out
        return redirect('volunteer_dashboard', id=id)

    #parse time into a datetime object
    #Format of string: Weekday: HH:MMam - HH:MMpm
    #Splitting by whitespace gives "Weekday:", "HH:MM:am", "-", "HH:MMpm"
    weekday = (time.split()[0])[:-1]
    startstr = time.split()[1]
    endstr = time.split()[3]

    #if (weekday == "Mon"):
#        weekday = "Monday"
#    elif (weekday == "Tue"):
#        weekday = "Tuesday"
#    elif (weekday == "Wed"):
#        weekday = "Wednesday"
#    elif (weekday == "Thu"):
#        weekday = "Thursday"
#    elif (weekday == "Fri"):
#        weekday = "Friday"
#    elif (weekday == "Sat"):
#        weekday = "Saturday"
#    elif (weekday == "Sun"):
#        weekday = "Sunday"

    start = datetime.strptime(startstr, "%I:%m%p").time()
    end = datetime.strptime(endstr, "%I:%m%p").time()

    #increment current date so that it matches the weekday
    while (calendar.day_name[currentday.weekday()] != weekday):
        currentday += timedelta(days = 1)

    currentday += timedelta(days = 7)
    #Then create a new session every week until the end day
    while (currentday < endday):
        Session.objects.create(
            user_id_tutor = Tutor.objects.get(User_ID = tid),
            user_id_client = Takes.objects.get(takes_id = takeid).student_name.user_id_client,
            student_name = Student.objects.get(student_id = student),
            subject_id = thistake.subject,
            date = currentday,
            start_time = datetime.combine(currentday, start),
            end_time = datetime.combine(currentday, end),
            location = loc,
            status = "In Future"
            )
        currentday += timedelta(days = 7)
    return redirect('volunteer_dashboard', id=tid)

def client_dashboard(request):
    sessions = Session.objects.all()
    return render(request, 'clientdashboard.html', {'sessions': sessions})

def editstudents(request):
    students = Student.objects.all()
    return render(request, 'editstudents.html', {'students': students})

def editsubject(request):
    takes = Takes.objects.all()
    return render(request, 'editsubject.html', {'takes': takes})

def edit_sessions(request, uid, sid):
    tutor = Tutor.objects.get(User_ID = uid)
    session = Session.objects.get(session_id = sid)
    locations = Location.objects.all()
    return render(request, 'changesession.html', {'session': session, 'locations': locations, 'tutor': tutor})

def submit_edited_sessions(request, id):
    session = Session.objects.get(session_id = id)
    if request.method == 'POST':
        newdate = request.POST.get('newdate', session.date)
        starttime = request.POST.get('newstart', session.start_time)
        endtime = request.POST.get('newend', session.end_time)
        loc = request.POST.get('changedloc', session.location)

        if (newdate != ''):
            session.date = newdate
        else:
            newdate = session.date

        if (starttime != ''):
            session.start_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(starttime, '%H:%M').time())

        if (endtime != ''):
            session.end_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(endtime, '%H:%M').time())

        #if (session.location != loc):
            #session.location = loc

        if (newdate == '' and starttime == '' and endtime == '' and session.location == loc):
            session.status = session.status
        else:
            session.status = "Pending Client Approval"

        session.save()

    return redirect('volunteer_dashboard', id=id)

def cancel_session(request, id):
    session = Session.objects.get(session_id = id)
    if request.method == 'POST':
        session.status = "Cancelled"
        session.save()
    return redirect('volunteer_dashboard', id=id)
