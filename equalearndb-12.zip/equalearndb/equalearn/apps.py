from django.apps import AppConfig


class EqualearnConfig(AppConfig):
    name = 'equalearn'
