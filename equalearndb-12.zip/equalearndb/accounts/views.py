from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from accounts.forms import SignUpForm
from equalearn.models import User as EqualearnUser
from equalearn.models import Tutor
from equalearn.models import Client
from equalearn.models import Executive
from django.http import HttpResponseRedirect
from django.urls import reverse

def pagelogout(request):
    if request.method == "POST":
        logout(request)
        return redirect('home')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            fname = form.cleaned_data.get('first_name')
            lname = form.cleaned_data.get('last_name')
            name = fname + " " + lname
            email = form.cleaned_data.get('email')
            user = authenticate(username=username, password=raw_password)
            #login(request, user)
            newuser = EqualearnUser.objects.create(name = name, username = username, email = email, phone_number="x")
            return redirect('choose_account', id=newuser.User_ID)
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

def choose_account(request, id):
    user = EqualearnUser.objects.get(User_ID = id)
    return render(request, 'chooseaccount.html', {'user': user})

def client_app(request, id):
    client = EqualearnUser.objects.get(User_ID = id)
    return render(request, 'clientapplication.html', {'client': client})

def tutor_app(request, id):
    tutor = EqualearnUser.objects.get(User_ID = id)
    return render(request, 'tutorapplication.html', {'tutor': tutor})

def choose_tutor(request, id):
    if request.method == 'POST':
        user = EqualearnUser.objects.get(User_ID = id)
        user.usertype = "tutor"
        user.save()

        tutor = Tutor.objects.create(
         User_ID = user.User_ID,
         username = user.username,
         usertype = "tutor",
         name = user.name,
         email = user.email,
         phone_number = "xxx-xxx-xxxx", #get this in volunteer form or sign-up form please
         preference_online = request.POST.get("preference")
        )

    return redirect('login')

def choose_exec(request, id):
    if request.method == 'POST':
        user = EqualearnUser.objects.get(User_ID = id)
        user.usertype = "executive"
        user.save()
        exec = Executive.objects.create(
            User_ID = user.User_ID,
            username = user.username,
            usertype = "executive",
            name = user.name,
            email = user.email,
            phone_number = user.phone_number,
            position = "placeholder"
        )
    return redirect('login')

def choose_client(request, id):
    if request.method == 'POST':
        user = EqualearnUser.objects.get(User_ID = id)
        user.usertype = "client"
        user.save()
        exec = Client.objects.create(
            User_ID = user.User_ID,
            username = user.username,
            usertype = "client",
            name = user.name,
            email = user.email,
            phone_number = request.POST.get("number"),
            referred_organization = request.POST.get("org"),
            proof_of_low_income = True
        )
    return redirect('login')

def getusername(request):
    return HttpResponseRedirect(reverse('home', args=[request.user.username]))

def home(request, username):
    #username = HttpResponseRedirect(reverse())
    user = EqualearnUser.objects.get(username = username)
    type = user.usertype
    if (type == "executive"):
        return redirect('executive_dashboard', id=user.User_ID)
    elif (type == "tutor"):
        return redirect('volunteer_dashboard', id = user.User_ID)
    elif (type == "client"):
        return redirect('client_dashboard', id = user.User_ID)
    else:
        return redirect('login')
