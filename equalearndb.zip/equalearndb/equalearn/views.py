from django.shortcuts import render
from django.http import HttpResponse
import django.contrib.staticfiles
from .models import User
from .models import Tutor
from .models import Client
from .models import Student
from .models import Session
from .models import Subject
from .models import Takes



# Create your views here.
def volunteer_dashboard(request):
    sessions = Session.objects.all()
    return render(request, 'volunteerdashboard.html', {'sessions': sessions})

def volunteer_hours(request):
    sessions = Session.objects.filter(status ='Verified')
    total = 0
    for session in sessions:
        total = total + session.totalhours()

    return render(request, 'viewhours.html', {'sessions': sessions, 'hours': total})

def session_signups(request):
    takes = Takes.objects.filter(current_tutor = None)
    return render(request, 'sessionsignups.html', {'takes': takes})

def client_dashboard(request):
    sessions = Session.objects.all()
    return render(request, 'clientdashboard.html', {'sessions': sessions})

def editstudents(request):
    students = Student.objects.all()
    return render(request, 'editstudents.html', {'students': students})

def editsubject(request):
    takes = Takes.objects.all()
    return render(request, 'editsubject.html', {'takes': takes})