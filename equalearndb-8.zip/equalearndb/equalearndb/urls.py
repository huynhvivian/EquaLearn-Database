"""equalearndb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from equalearn import views
from accounts import views as accounts_views

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'volunteer_dashboard/(?P<id>\d+)/$', views.volunteer_dashboard, name="volunteer_dashboard"),
    url(r'executive_dashboard/(?P<id>\d+)/$', views.executive_dashboard, name = "executive_dashboard"),
    url(r'volunteer_hours/(?P<id>\d+)/$', views.volunteer_hours, name = "volunteer_hours"),
    url(r'view_volunteer_hours/(?P<eid>\d+)/(?P<tid>\d+)/$', views.view_volunteer_hours, name = "view_volunteer_hours"),
    url(r'approve_hours/(?P<eid>\d+)/$', views.approve_hours, name = "approve_hours"),
    url(r'session_signups/(?P<id>\d+)/$', views.session_signups, name = "session_signups"),
    path('signup', accounts_views.signup, name='signup'),
    url(r'edit_session/(?P<uid>\d+)/(?P<sid>\d+)/$', views.edit_sessions, name = "edit_session"),
    url(r'confirm_session/(?P<tid>\d+)/(?P<sid>\d+)/$', views.submit_edited_sessions, name = "confirm_session"),
    url(r'cancel_session/(?P<tid>\d+)/(?P<sid>\d+)/$', views.cancel_session, name = "cancel_session"),
    url(r'view_sessions/(?P<eid>\d+)/$', views.view_pending_sessions, name = "view_sessions"),
    url(r'approve_sessions/(?P<eid>\d+)/(?P<psessionid>\d+)/$', views.approve_sessions, name = "approve_sessions"),
    url(r'sessions_signed_up/(?P<tid>\d+)/(?P<takeid>\d+)/$', views.sessions_signed_up, name = "sessions_signed_up"),
    path('client_dashboard', views.client_dashboard, name="clients"),
    path('editstudents', views.editstudents),
    path('editsubject', views.editsubject)
]
