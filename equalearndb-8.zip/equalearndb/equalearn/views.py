from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
import django.contrib.staticfiles
import random
import calendar
from datetime import date
from datetime import datetime
from datetime import timedelta
from .models import User
from .models import Executive
from .models import Tutor
from .models import Client
from .models import Student
from .models import Session
from .models import Subject
from .models import Takes
from .models import Location
from.models import schedule_student
from .models import preferred_student
from .models import PendingSession



# Create your views here.

def executive_dashboard(request, id):
    #id = exec's user ID
    exec = Executive.objects.get(User_ID = id)
    return render(request, 'execdashboard.html', {'executive': exec})

def volunteer_dashboard(request, id):
    #id = volunteer's user ID
    tutor = Tutor.objects.get(User_ID = id)
    sessions = Session.objects.filter(user_id_tutor = id)
    return render(request, 'volunteerdashboard.html', {'sessions': sessions, 'tutor': tutor})

def volunteer_hours(request, id):
    tutor = Tutor.objects.get(User_ID = id)
    sessions = Session.objects.filter(status ='Verified', user_id_tutor = id)
    total = 0
    for session in sessions:
        total = total + session.totalhours()

    return render(request, 'viewhours.html', {'sessions': sessions, 'hours': total, 'tutor': tutor})

def session_signups(request, id):
    tutor = Tutor.objects.get(User_ID = id)
    takes = Takes.objects.filter(current_tutor = None)
    student_schedules = schedule_student.objects.all()
    student_locations = preferred_student.objects.all()
    return render(request, 'sessionsignups.html', {'takes': takes, 'tutor': tutor, 'schedules':student_schedules, 'student_locations': student_locations})


def view_pending_sessions(request, eid):
    exec = Executive.objects.get(User_ID = eid)
    pendingsessions = PendingSession.objects.all()
    return render(request, 'approvesessions.html', {'executive': exec, 'sessions': pendingsessions})

def approve_sessions(request, eid, psessionid):
    #We need: Client ID, location, timeslot, volunteer, and approve button. We get that information from takes and the volunteer...?
    pendingsession = PendingSession.objects.get(sessions_id = psessionid)

    takes = pendingsession.takes_object
    tutor = pendingsession.user_id_tutor

    endday = takes.end_date
    weekday = pendingsession.weekday
    start = pendingsession.start_time
    end = pendingsession.end_time
    loc = pendingsession.location

    currentday = datetime.date(datetime.now())

    #creating sessions
    while (calendar.day_name[currentday.weekday()] != weekday):
        currentday += timedelta(days = 1)

    currentday += timedelta(days = 7)
    #Then create a new session every week until the end day
    while (currentday < endday):
        Session.objects.create(
            user_id_tutor = tutor,
            user_id_client = takes.student_name.user_id_client,
            student_name = takes.student_name,
            subject_id = takes.subject,
            date = currentday,
            start_time = datetime.combine(currentday, start),
            end_time = datetime.combine(currentday, end),
            location = loc,
            status = "In Future"
            )
        currentday += timedelta(days = 7)

    #Delete pendingsessions object
    pendingsession.delete()
    return redirect('executive_dashboard', id=eid)

def sessions_signed_up(request, tid, takeid):
    #Make sessions from next-next session to the end... so we'd need current date, the weekday, ummm
    currentday = datetime.date(datetime.now())
    thistake = Takes.objects.get(takes_id = takeid)
    thistake.current_tutor = Tutor.objects.get(User_ID = tid)
    thistake.save()
    endday = thistake.end_date


    loc = request.POST.get('chooseloc')
    time = request.POST.get('choosetime')
    if (loc == '' or time == ''):
        #no time or location filled out
        return redirect('volunteer_dashboard', id=tid)

    #parse time into a datetime object
    #Format of string: Weekday: HH:MMam - HH:MMpm
    #Splitting by whitespace gives "Weekday:", "HH:MM:am", "-", "HH:MMpm"
    weekday = (time.split()[0])[:-1]
    startstr = time.split()[1]
    endstr = time.split()[3]

    start = datetime.strptime(startstr, "%I:%m%p").time()
    end = datetime.strptime(endstr, "%I:%m%p").time()

    #create pendingsession object
    PendingSession.objects.create(
        user_id_tutor = thistake.current_tutor,
        user_id_client = thistake.student_name.user_id_client,
        takes_object = thistake,
        weekday = weekday,
        start_time = start,
        end_time = end,
        location = loc
    )

    return redirect('volunteer_dashboard', id=tid)

def approve_hours(request, eid):
    tutors = Tutor.objects.all()
    exec = Executive.objects.get(User_ID = eid)
    return render(request, 'approvehours.html', {'tutors': tutors, 'executive': exec})

def view_volunteer_hours(request, eid, tid):
    tutor = Tutor.objects.get(User_ID = tid)
    exec = Executive.objects.get(User_ID = eid)
    sessions = Session.objects.filter(status ='Verified', user_id_tutor = tid)
    total = 0
    for session in sessions:
        total = total + session.totalhours()
    return render(request, 'viewvolunteerhours.html', {'tutor': tutor, 'executive': exec, 'hours': total, 'sessions': sessions})

def client_dashboard(request):
    sessions = Session.objects.all()
    return render(request, 'clientdashboard.html', {'sessions': sessions})

def editstudents(request):
    students = Student.objects.all()
    return render(request, 'editstudents.html', {'students': students})

def editsubject(request):
    takes = Takes.objects.all()
    return render(request, 'editsubject.html', {'takes': takes})

def edit_sessions(request, uid, sid):
    tutor = Tutor.objects.get(User_ID = uid)
    session = Session.objects.get(session_id = sid)
    locations = Location.objects.all()
    return render(request, 'changesession.html', {'session': session, 'locations': locations, 'tutor': tutor})

def submit_edited_sessions(request, tid, sid):
    session = Session.objects.get(session_id = sid)
    if request.method == 'POST':
        newdate = request.POST.get('newdate', session.date)
        starttime = request.POST.get('newstart', session.start_time)
        endtime = request.POST.get('newend', session.end_time)
        loc = request.POST.get('changedloc', session.location)

        if (newdate != ''):
            session.date = newdate
        else:
            newdate = session.date

        if (starttime != ''):
            session.start_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(starttime, '%H:%M').time())

        if (endtime != ''):
            session.end_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(endtime, '%H:%M').time())

        #if (session.location != loc):
            #session.location = loc

        if (newdate == '' and starttime == '' and endtime == '' and session.location == loc):
            session.status = session.status
        else:
            session.status = "Pending Client Approval"

        session.save()

    return redirect('volunteer_dashboard', id=tid)

def cancel_session(request, tid, sid):
    session = Session.objects.get(session_id = sid)
    if request.method == 'POST':
        session.status = "Cancelled"
        session.save()
    return redirect('volunteer_dashboard', id=tid)
