from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
import django.contrib.staticfiles
import random
from datetime import date
from datetime import datetime
from .models import User
from .models import Tutor
from .models import Client
from .models import Student
from .models import Session
from .models import Subject
from .models import Takes
from .models import Location



# Create your views here.
def volunteer_dashboard(request):
    sessions = Session.objects.all()
    return render(request, 'volunteerdashboard.html', {'sessions': sessions})

def volunteer_hours(request):
    sessions = Session.objects.filter(status ='Verified')
    total = 0
    for session in sessions:
        total = total + session.totalhours()

    return render(request, 'viewhours.html', {'sessions': sessions, 'hours': total})

def session_signups(request):
    takes = Takes.objects.filter(current_tutor = None)
    return render(request, 'sessionsignups.html', {'takes': takes})

#def sessions_signed_up(request, pk):
#    Sessions.objects.create(
#        user_id_tutor = Tutor.objects.first() #temporary
#        user_id_client = Takes.objects.get(student_name = pk).student_name.user_id_client
#        student_name = Student.objects.get(student_name = pk)
#    )

def edit_sessions(request, id):
    session = Session.objects.get(session_id = id)
    locations = Location.objects.all()
    return render(request, 'changesession.html', {'session': session, 'locations': locations})

def submit_edited_sessions(request, id):
    session = Session.objects.get(session_id = id)
    if request.method == 'POST':
        newdate = request.POST.get('newdate', session.date)
        starttime = request.POST.get('newstart', session.start_time)
        endtime = request.POST.get('newend', session.end_time)
        loc = request.POST.get('changedloc', session.location)

        if (newdate != ''):
            session.date = newdate
        else:
            newdate = session.date

        if (starttime != ''):
            session.start_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(starttime, '%H:%M').time())

        if (endtime != ''):
            session.end_time = datetime.combine(datetime.strptime(newdate, '%Y-%m-%d'), datetime.strptime(endtime, '%H:%M').time())

        #if (session.location != loc):
            #session.location = loc

        if (newdate == '' and starttime == '' and endtime == '' and session.location == loc):
            session.status = session.status
        else:
            session.status = "Pending Client Approval"

        session.save()

    return redirect('volunteer_dashboard')

def cancel_session(request, id):
    session = Session.objects.get(session_id = id)
    if request.method == 'POST':
        session.status = "Cancelled"
        session.save()
    return redirect('volunteer_dashboard')
