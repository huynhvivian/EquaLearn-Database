"""equalearndb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from equalearn import views
from accounts import views as accounts_views

urlpatterns = [
    path('admin/', admin.site.urls),
    url('volunteer_dashboard', views.volunteer_dashboard, name="volunteer_dashboard"),
    path('volunteer_hours', views.volunteer_hours),
    path('session_signups', views.session_signups),
    path('signup', accounts_views.signup, name='signup'),
    url(r'edit_session/(?P<id>\d+)/$', views.edit_sessions, name = "edit_session"),
    url(r'confirm_session/(?P<id>\d+)/$', views.submit_edited_sessions, name = "confirm_session"),
    url(r'cancel_session/(?P<id>\d+)/$', views.cancel_session, name = "cancel_session")
]
